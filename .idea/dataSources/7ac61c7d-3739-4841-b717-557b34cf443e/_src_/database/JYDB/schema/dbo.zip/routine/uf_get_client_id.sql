CREATE FUNCTION dbo.uf_get_client_id()
	RETURNS bigint
	AS
	BEGIN
		DECLARE @dt DATETIME,@stamp BIGINT
		SELECT @dt=CURR_DATE from dbo.V_GETDATE
		SELECT @stamp=datediff(DAY,'2000-01-01',@dt)
		SELECT @stamp=(@stamp)*86400000
		select @stamp=@stamp+
		DATEDIFF(ms,CONVERT(DATETIME,CONVERT(VARCHAR(10),@dt)),@dt) 
		return @stamp 
	END;

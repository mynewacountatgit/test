CREATE PROCEDURE [dbo].[USPUSI_SaveUserName] @username varchar(250)
AS
update dbo.usiLOCASYSTEM set CVALUE =@username where BH='USERNAME'
if(@@rowcount=0)
insert dbo.usiLOCASYSTEM (BH,MS,IVALUE,FVALUE,DVALUE,CVALUE,I64VALUE)
values('USERNAME','用户名称',null,null,null,@username,null)
return 0;

CREATE VIEW `v_fund_month_risk` AS
  /

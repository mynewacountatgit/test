CREATE VIEW `v_fund_org_month_risk` AS
  /

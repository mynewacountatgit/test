CREATE VIEW `v_fund_month_performance` AS
  /

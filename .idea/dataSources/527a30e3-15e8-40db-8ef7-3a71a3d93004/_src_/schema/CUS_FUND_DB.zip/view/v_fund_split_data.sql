CREATE VIEW `v_fund_split_data` AS
  /

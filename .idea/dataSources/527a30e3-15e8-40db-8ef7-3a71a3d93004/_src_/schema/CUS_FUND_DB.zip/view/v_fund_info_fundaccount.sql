CREATE VIEW `v_fund_info_fundaccount` AS
  /

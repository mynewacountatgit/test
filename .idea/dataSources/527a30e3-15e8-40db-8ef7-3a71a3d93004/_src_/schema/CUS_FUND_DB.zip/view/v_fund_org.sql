CREATE VIEW `v_fund_org` AS
  /

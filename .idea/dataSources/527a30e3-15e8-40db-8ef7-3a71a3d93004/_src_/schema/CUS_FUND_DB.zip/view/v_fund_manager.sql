CREATE VIEW `v_fund_manager` AS
  /

CREATE VIEW `v_fund_weekly_risk` AS
  /

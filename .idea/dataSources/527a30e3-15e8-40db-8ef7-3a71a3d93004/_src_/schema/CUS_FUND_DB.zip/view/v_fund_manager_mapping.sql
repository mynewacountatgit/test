CREATE VIEW `v_fund_manager_mapping` AS
  /

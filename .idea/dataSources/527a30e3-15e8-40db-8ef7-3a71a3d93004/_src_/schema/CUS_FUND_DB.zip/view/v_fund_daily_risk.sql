CREATE VIEW `v_fund_daily_risk` AS
  /

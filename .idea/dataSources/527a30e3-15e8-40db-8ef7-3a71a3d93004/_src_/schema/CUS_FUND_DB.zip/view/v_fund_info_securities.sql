CREATE VIEW `v_fund_info_securities` AS
  /

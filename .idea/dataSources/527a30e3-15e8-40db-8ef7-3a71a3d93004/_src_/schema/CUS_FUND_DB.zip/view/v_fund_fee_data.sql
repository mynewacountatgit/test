CREATE VIEW `v_fund_fee_data` AS
  /

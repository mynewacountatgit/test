CREATE VIEW `v_fund_info` AS
  /

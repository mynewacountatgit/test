CREATE VIEW `v_fund_annully_performance` AS
  /

CREATE VIEW `v_fund_org_executive_info` AS
  /

CREATE VIEW `v_fund_portfolio` AS
  /

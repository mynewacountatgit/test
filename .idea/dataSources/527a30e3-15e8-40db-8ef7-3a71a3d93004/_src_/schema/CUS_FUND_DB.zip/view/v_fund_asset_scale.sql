CREATE VIEW `v_fund_asset_scale` AS
  /

CREATE VIEW `v_fund_info_futures` AS
  /

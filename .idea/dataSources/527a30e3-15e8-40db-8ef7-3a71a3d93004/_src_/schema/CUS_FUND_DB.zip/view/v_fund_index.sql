CREATE VIEW `v_fund_index` AS
  /

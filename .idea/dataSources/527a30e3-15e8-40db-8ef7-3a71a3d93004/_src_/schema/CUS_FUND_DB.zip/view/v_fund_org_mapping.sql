CREATE VIEW `v_fund_org_mapping` AS
  /

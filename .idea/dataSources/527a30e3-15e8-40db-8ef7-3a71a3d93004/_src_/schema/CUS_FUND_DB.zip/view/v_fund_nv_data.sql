CREATE VIEW `v_fund_nv_data` AS
  /

CREATE VIEW `v_fund_weekly_performance` AS
  /

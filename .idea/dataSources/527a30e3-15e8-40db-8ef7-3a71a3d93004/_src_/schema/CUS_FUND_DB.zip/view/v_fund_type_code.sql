CREATE VIEW `v_fund_type_code` AS
  /

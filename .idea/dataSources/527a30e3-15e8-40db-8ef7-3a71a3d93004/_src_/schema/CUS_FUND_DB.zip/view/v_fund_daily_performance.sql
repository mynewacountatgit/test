CREATE VIEW `v_fund_daily_performance` AS
  /

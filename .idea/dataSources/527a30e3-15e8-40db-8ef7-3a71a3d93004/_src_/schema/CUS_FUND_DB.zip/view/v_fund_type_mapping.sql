CREATE VIEW `v_fund_type_mapping` AS
  /

CREATE VIEW `v_fund_change_data` AS
  /

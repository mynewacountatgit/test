

```python
import pandas
import tushare
from matplotlib import pyplot as plt
import matplotlib
matplotlib.style.use("ggplot")
## 导入相关包
```


```python
market = tushare.get_h_data('000001', index=True, start="2006-01-01").sort_index()
market_sz = tushare.get_h_data('399004', index=True, start="2006-01-01").sort_index()
market_hs = tushare.get_h_data('000300', index=True, start="2006-01-01").sort_index()
market_cy = tushare.get_h_data('399606', index=True, start="2010-01-01").sort_index()
## 获得各个股指对应的数据
##000001    上证指数 
## 399004  深证100R  
##399606    创业板R 
## 000300   沪深300
```

    [Getting data:]############################################[Getting data:]############################################[Getting data:]############################################[Getting data:]############################


```python

def try_para(market,p):
    market = market.sort_index()
    ## 周重采样平均，以p为参数，对周频数据滚动平均
    base = market["amount"].resample("w").mean().dropna().rolling(p).mean()
    ##  每周的末的收盘价与每周初的开盘价，算收益率
    delta = ((market.close.resample("w").last() - market.open.resample("w").first()) / market.open.resample("w").first()).dropna()
    ##  策略信号，如果比上周大，就多，基于每周末平仓
    signal = base > base.shift(1)
    ## 计算累积收益率
    gain = (1 + signal.shift(1) * delta).dropna().cumprod()
    return gain

```


```python

def plot_st(market,k,n):
    plot1, = plt.plot(market.close, label="  index")
    handles = [plot1]
    for i in range(k,n):
        gain = try_para(market,i)
        plot2, = plt.plot(market.close[0] * gain, label="Strategy"+str(i))
        handles.append(plot2)
    plt.legend(handles=handles)
    plt.show()
## 画图函数
```


```python
plot_st(market,3,9)
plot_st(market_sz,3,9)
plot_st(market_hs,3,9)



plot_st(market["2008":],3,9)
plot_st(market_sz["2008":],3,9)
plot_st(market_hs["2008":],3,9)



plot_st(market["2010":],3,9)
plot_st(market_sz["2010":],3,9)
plot_st(market_hs["2010":],3,9)
plot_st(market_cy["2010":],3,9)

plot_st(market["2015":],3,9)
plot_st(market_sz["2015":],3,9)
plot_st(market_hs["2015":],3,9)
plot_st(market_cy["2015":],3,9)


plot_st(market["2016":],3,9)
plot_st(market_sz["2016":],3,9)
plot_st(market_hs["2016":],3,9)
plot_st(market_cy["2016":],3,9)



```


![png](output_4_0.png)



![png](output_4_1.png)



![png](output_4_2.png)



![png](output_4_3.png)



![png](output_4_4.png)



![png](output_4_5.png)



![png](output_4_6.png)



![png](output_4_7.png)



![png](output_4_8.png)



![png](output_4_9.png)



![png](output_4_10.png)



![png](output_4_11.png)



![png](output_4_12.png)



![png](output_4_13.png)



![png](output_4_14.png)



![png](output_4_15.png)



![png](output_4_16.png)



![png](output_4_17.png)



```python

```
